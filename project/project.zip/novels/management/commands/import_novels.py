# import csv
# from django.core.management.base import BaseCommand
# from novels.models import Novel  # adapte si ton modèle est ailleurs
# import re

# class Command(BaseCommand):
#     help = 'Import novels from wn.csv'

#     def add_arguments(self, parser):
#         parser.add_argument('csv_file', type=str, help='Path to the wn.csv file')

#     def handle(self, *args, **kwargs):
#         csv_file = kwargs['csv_file']
#         with open(csv_file, mode='r', encoding='utf-8') as f:
#             reader = csv.DictReader(f)
#             novels = []
#             for row in reader:
#                 novel = Novel(
#                     novel_id=int(row['novel_id']) if row['novel_id'] else None,
#                     url=row['url'],
#                     title=row['title'],
#                     associated_names=row['associated_names'],
#                     img_url=row['img_url'],
#                     showtype=row['showtype'],
#                     genres=row['genres'],
#                     tags=row['tags'],
#                     description=row['description'],
#                     related_series=row['related_series'],
#                     recommendations=row['recommendations'],
#                     recommendation_lists=row['recommendation_lists'],
                    
#                     rating_match = re.search(r"(\d+(\.\d+)?)", row['rating'])
#                     rating = float(rating_match.group(1)) if rating_match else None

#                     language=row['language'],
#                     authors=row['authors'],
#                     artists=row['artists'],
#                     year=row['year'],
#                     status_coo=row['status_coo'],
#                     licensed=row['licensed'],
#                     translated=row['translated'],
#                     publishers=row['publishers'],
#                     en_pubs=row['en_pubs'],
#                     release_frequency=row['release_frequency'],
#                     weekly_rank=row['weekly_rank'],
#                     monthly_rank=row['monthly_rank'],
#                     all_time_rank=row['all_time_rank'],
#                     monthly_rank_reading_list=row['monthly_rank_reading_list'],
#                     all_time_rank_reading_list=row['all_time_rank_reading_list'],
#                     total_reading_list_rank=row['total_reading_list_rank'],
#                     chapters=row['chapters'],
#                 )
#                 novels.append(novel)

#             Novel.objects.bulk_create(novels, batch_size=100)
#             self.stdout.write(self.style.SUCCESS(f'Successfully imported {len(novels)} novels.'))

import csv
import re
from django.core.management.base import BaseCommand
from novels.models import Novel

class Command(BaseCommand):
    help = 'Import novels from a CSV file'

    def add_arguments(self, parser):
        parser.add_argument('csv_file', type=str)

    def handle(self, *args, **options):
        with open(options['csv_file'], newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                rating_match = re.search(r"(\d+(\.\d+)?)", row.get('rating', ''))
                rating_value = float(rating_match.group(1)) if rating_match else None

                rank_value = row.get('rank', '')
                if rank_value.startswith('#'):
                    rank_value = int(rank_value[1:]) if rank_value[1:].isdigit() else None
                else:
                    rank_value = int(rank_value) if rank_value.isdigit() else None

                Novel.objects.create(
                    title=row.get('title'),
                    author=row.get('authors'),
                    tags=row.get('tags'),
                    genre=row.get('genres'),
                    description=row.get('description'),
                    rating=rating_value,
                    rank=rank_value,
                    status=row.get('status'),
                    chapters=int(row['chapters']) if row.get('chapters') and row['chapters'].isdigit() else None,
                    views=int(row['views'].replace(',', '')) if row.get('views') and row['views'].replace(',', '').isdigit() else None,
                    img_url=row.get('img_url')
                )

        self.stdout.write(self.style.SUCCESS('📚 Novels imported successfully!'))
