# from django.db import models
# from django.contrib.auth.models import User

# class Novel(models.Model):
#     novel_id = models.IntegerField(unique=True)
#     url = models.CharField(max_length=255)
#     title = models.CharField(max_length=255)
#     associated_names = models.TextField(blank=True)
#     img_url = models.URLField()
#     showtype = models.CharField(max_length=50)
#     genres = models.TextField()
#     tags = models.TextField()
#     description = models.TextField()
#     rating = models.CharField(max_length=50)
#     language = models.CharField(max_length=50)
#     authors = models.TextField()
#     year = models.CharField(max_length=50)
#     status = models.CharField(max_length=100)

#     def __str__(self):
#         return self.title

# class Review(models.Model):
#     novel = models.ForeignKey(Novel, on_delete=models.CASCADE, related_name='reviews')
#     user = models.ForeignKey(User, on_delete=models.CASCADE)
#     rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])
#     comment = models.TextField()
#     created_at = models.DateTimeField(auto_now_add=True)

#     class Meta:
#         unique_together = ('novel', 'user')

#     def __str__(self):
#         return f'Review by {self.user.username} for {self.novel.title}'


from django.db import models
from django.contrib.auth.models import User


class Novel(models.Model):
    title = models.CharField(max_length=255)
    author = models.CharField(max_length=255, null=True, blank=True)
    genre = models.CharField(max_length=255, null=True, blank=True)
    tags = models.CharField(max_length=255, null=True, blank=True)
    description = models.TextField(null=True, blank=True)
    rating = models.FloatField(null=True, blank=True)
    rank = models.IntegerField(null=True, blank=True)
    status = models.CharField(max_length=50, null=True, blank=True)
    chapters = models.IntegerField(null=True, blank=True)
    views = models.IntegerField(null=True, blank=True)
    img_url = models.URLField(null=True, blank=True)

    def __str__(self):
        return self.name

class Review(models.Model):
    novel = models.ForeignKey(Novel, on_delete=models.CASCADE, related_name='reviews')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])
    comment = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('novel', 'user')  # 1 review max par user/novel

    def __str__(self):
        return f'Review by {self.user.username} for {self.novel.name}'
